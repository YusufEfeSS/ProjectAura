# PROJECT AURA

Kotlin ile yazılmış yerel Android asistanı (Compose/WebView/PWA yok; harici bağımlılık yok).

- minSdk 26 (Android 8.0), compileSdk/targetSdk 35
- Ses tanıma ve sesli cevap: Android SpeechRecognizer / TextToSpeech (tr-TR)
- Notlar, görevler, sohbet geçmişi ve ayarlar: cihazda yerel kayıt
- Hesap makinesi, saat, kronometre
- Yapay zekâ sohbeti: yalnızca KENDİ https sunucunuz üzerinden (bkz. `server/cloudflare-worker.js`).
  API anahtarı uygulamaya ve bu depoya konmaz. Sunucu adresi girilmezse AI sohbeti kapalıdır.

## Derleme

GitHub > Actions > "Build Aura APK" > Run workflow. Çıktı: `ProjectAura-debug-apk` artifact (içinde `app-debug.apk`).
APK, Gradle'ın otomatik oluşturduğu debug anahtarıyla imzalanır.

## Sesli yerel komut örnekleri

"saat kaç", "bugün günlerden ne", "not ekle yarın süt al", "görev ekle faturayı öde",
"notlarımı oku", "görevlerimi oku", "hesapla 12 çarpı 4". Diğer her şey AI sunucusuna gider.
