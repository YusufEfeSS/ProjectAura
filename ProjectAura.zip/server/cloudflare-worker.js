// PROJECT AURA için ÖRNEK güvenli sunucu (Cloudflare Worker). Bu dosya Android uygulamasının parçası DEĞİLDİR.
// API anahtarı yalnızca burada, sunucu tarafında "secret" olarak durur.
//
// Gerekli secret/değişkenler (Cloudflare panelinden):
//   ANTHROPIC_API_KEY  -> yapay zekâ servisi API anahtarınız (secret)
//   APP_TOKEN          -> uzun rastgele bir metin; uygulamadaki "erişim jetonu" ile aynı olmalı (secret)
//   MODEL              -> isteğe bağlı model adı (varsayılan aşağıda)
//
// Uygulama sözleşmesi:
//   İstek : POST  {"messages":[{"role":"user|assistant","content":"..."}],"lang":"tr"}
//   Cevap : {"reply":"..."}

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });

export default {
  async fetch(request, env) {
    if (request.method !== "POST") return json({ error: "POST gerekli" }, 405);

    const auth = request.headers.get("Authorization") || "";
    if (!env.APP_TOKEN || auth !== "Bearer " + env.APP_TOKEN) {
      return json({ error: "yetkisiz" }, 401);
    }

    let body;
    try {
      body = await request.json();
    } catch (e) {
      return json({ error: "gecersiz JSON" }, 400);
    }

    const messages = (Array.isArray(body.messages) ? body.messages : [])
      .filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim())
      .slice(-20)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 4000) }));
    while (messages.length && messages[0].role !== "user") messages.shift();
    if (!messages.length || messages[messages.length - 1].role !== "user") {
      return json({ error: "son mesaj kullanicidan olmali" }, 400);
    }

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: env.MODEL || "claude-sonnet-5-5",
        max_tokens: 600,
        system:
          "Sen PROJECT AURA adlı, Türkçe konuşan kişisel bir asistansın. Kısa, net ve sesli okunmaya uygun yanıt ver.",
        messages,
      }),
    });

    if (!r.ok) return json({ error: "yapay zeka servisi hatasi", status: r.status }, 502);
    const data = await r.json();
    const reply = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n")
      .trim();
    return json({ reply });
  },
};
