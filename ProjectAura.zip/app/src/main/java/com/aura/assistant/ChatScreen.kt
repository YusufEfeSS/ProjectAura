package com.aura.assistant

import android.app.AlertDialog
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class ChatScreen(private val app: MainActivity) : Screen() {
    private val list = vbox(app)
    private val scroll = ScrollView(app)
    private val input = field(app, "Aura'ya yazın…").apply {
        imeOptions = EditorInfo.IME_ACTION_SEND
        setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else {
                false
            }
        }
    }
    private val micBtn = TextView(app).apply {
        text = "🎤"
        textSize = 20f
        gravity = Gravity.CENTER
        background = neon(app, C.panel, C.cyan, 22, 1)
        setOnClickListener { mic() }
    }
    private var shownCount = -1
    private var shownBusy = false

    init {
        app.assistant.observers.add { render() }
    }

    override val view: View by lazy { build() }

    private fun build(): View {
        val root = vbox(app)
        root.setPadding(app.dp(12), app.dp(8), app.dp(12), app.dp(8))

        val head = hbox(app)
        val title = tv(app, "SOHBET", 16f, C.cyan, true)
        title.typeface = MONO
        head.add(title, w = 0, weight = 1f)
        head.add(btn(app, "Geçmişi temizle", C.dim) { confirmClear() })
        root.add(head, b = 8)

        scroll.addView(list)
        root.add(scroll, h = 0, weight = 1f)

        val row = hbox(app)
        row.add(input, w = 0, weight = 1f)
        row.add(micBtn, w = app.dp(44), h = app.dp(44), l = 6)
        row.add(btn(app, "Gönder", C.cyan) { send() }, l = 6)
        root.add(row, t = 8)
        return root
    }

    override fun onShow() {
        shownCount = -1
        render()
    }

    private fun render() {
        val msgs = app.store.chat()
        val busy = app.assistant.busy
        if (msgs.size == shownCount && busy == shownBusy) return
        shownCount = msgs.size
        shownBusy = busy

        list.removeAllViews()
        if (msgs.isEmpty()) {
            list.add(tv(app, "Henüz mesaj yok. Bir şey yazın veya mikrofona dokunun.", 14f, C.dim), t = 16)
        }
        for (m in msgs) list.add(bubble(m.role, m.text), b = 8)
        if (busy) list.add(bubble("assistant", "Aura düşünüyor…"), b = 8)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun bubble(role: String, text: String): View {
        val user = role == "user"
        val err = role == "error"
        val color = when {
            err -> C.danger
            user -> C.cyan
            else -> C.purple
        }
        val t = tv(app, text, 15f, if (err) C.danger else C.text)
        t.background = neon(app, C.panel, color, 14)
        t.setPadding(app.dp(12), app.dp(8), app.dp(12), app.dp(8))
        t.maxWidth = (app.resources.displayMetrics.widthPixels * 0.8f).toInt()
        t.setTextIsSelectable(true)
        val row = LinearLayout(app)
        row.gravity = if (user) Gravity.END else Gravity.START
        row.addView(t, LinearLayout.LayoutParams(WRAP, WRAP))
        return row
    }

    private fun send() {
        if (app.assistant.busy) return
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        app.assistant.ask(t)
    }

    private fun mic() {
        val v = app.voice
        if (v.listening) {
            v.stopListening()
            return
        }
        if (app.assistant.busy) return
        app.ensureMic {
            input.setText("")
            micBtn.setTextColor(C.danger)
            v.startListening(
                cbPartial = {
                    input.setText(it)
                    input.setSelection(input.text.length)
                },
                cbFinal = {
                    input.setText("")
                    app.assistant.ask(it)
                },
                cbError = { Toast.makeText(app, it, Toast.LENGTH_LONG).show() },
                cbLevel = {},
                cbEnd = { micBtn.setTextColor(C.text) }
            )
        }
    }

    private fun confirmClear() {
        AlertDialog.Builder(app, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Sohbet geçmişi silinsin mi?")
            .setMessage("Bu işlem geri alınamaz.")
            .setPositiveButton("Sil") { _, _ ->
                app.store.clearChat()
                shownCount = -1
                render()
            }
            .setNegativeButton("İptal", null)
            .show()
    }
}
