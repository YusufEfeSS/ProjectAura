package com.aura.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Türkçe ses tanıma (SpeechRecognizer) ve sesli cevap (TextToSpeech). Tüm geri çağrılar ana iş parçacığında çalışır. */
class Voice(context: Context) {
    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsLangOk = false
    private var endCb: (() -> Unit)? = null

    var listening = false
        private set
    var speaking = false
        private set
    var onSpeakingChanged: (() -> Unit)? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    val r = tts?.setLanguage(Locale("tr", "TR"))
                    ttsLangOk = r != null && r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    ttsReady = true
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            main.post { setSpeaking(true) }
                        }

                        override fun onDone(utteranceId: String?) {
                            main.post { setSpeaking(false) }
                        }

                        @Suppress("OVERRIDE_DEPRECATION")
                        override fun onError(utteranceId: String?) {
                            main.post { setSpeaking(false) }
                        }
                    })
                }
            }
        }
    }

    private fun setSpeaking(v: Boolean) {
        if (speaking == v) return
        speaking = v
        onSpeakingChanged?.invoke()
    }

    /** Başarılıysa null, sorun varsa kullanıcıya gösterilecek Türkçe mesaj döner. */
    fun speak(text: String): String? {
        if (!ttsReady) return "Ses motoru henüz hazır değil. Birkaç saniye sonra tekrar deneyin."
        if (!ttsLangOk) {
            return "Telefonda Türkçe ses verisi yok. Ayarlar > Metin okuma bölümünden Türkçe ses verisini indirin."
        }
        tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "aura")
        return null
    }

    fun stopSpeaking() {
        tts?.stop()
        setSpeaking(false)
    }

    fun startListening(
        cbPartial: (String) -> Unit,
        cbFinal: (String) -> Unit,
        cbError: (String) -> Unit,
        cbLevel: (Float) -> Unit,
        cbEnd: () -> Unit
    ) {
        stopSpeaking()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            cbError("Bu telefonda ses tanıma servisi bulunamadı. Google uygulamasının yüklü ve güncel olduğundan emin olun.")
            cbEnd()
            return
        }
        cancelListening()

        var finished = false
        fun finish() {
            if (finished) return
            finished = true
            listening = false
            endCb = null
            val old = recognizer
            recognizer = null
            main.post { old?.destroy() }
            cbEnd()
        }

        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        listening = true
        endCb = { finish() }

        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                cbLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            }

            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                if (finished) return
                finish()
                cbError(describe(error))
            }

            override fun onResults(results: Bundle?) {
                if (finished) return
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.trim().orEmpty()
                finish()
                if (text.isEmpty()) cbError(describe(SpeechRecognizer.ERROR_NO_MATCH)) else cbFinal(text)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) cbPartial(text)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        r.startListening(intent)
    }

    /** Konuşmayı bitirir; sonuç normal akışla gelir. */
    fun stopListening() {
        recognizer?.stopListening()
    }

    /** Dinlemeyi sonuçsuz iptal eder. */
    fun cancelListening() {
        val r = recognizer
        r?.cancel()
        endCb?.invoke()
    }

    fun release() {
        cancelListening()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private fun describe(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
            "Sizi duyamadım. Mikrofona yakın ve net konuşup tekrar deneyin."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "Ses tanıma için internet bağlantısı gerekiyor. Bağlantınızı kontrol edin."
        SpeechRecognizer.ERROR_AUDIO ->
            "Mikrofona erişilemedi. Başka bir uygulama mikrofonu kullanıyor olabilir."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
            "Mikrofon izni verilmemiş. Uygulama ayarlarından izin verin."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
            "Ses tanıma meşgul. Birkaç saniye sonra tekrar deneyin."
        SpeechRecognizer.ERROR_SERVER ->
            "Ses tanıma sunucusu yanıt vermedi. Daha sonra tekrar deneyin."
        else -> "Ses tanıma hatası (kod $code)."
    }
}
