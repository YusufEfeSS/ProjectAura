package com.aura.assistant

import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Yerel komutları (not, görev, saat, hesap) işler; gerisini yapılandırılmış sunucuya (AI) gönderir. */
object Commands {
    private val tr = Locale("tr", "TR")

    private fun rest(orig: String, q: String, prefixes: List<String>): String? {
        for (p in prefixes) {
            if (q.startsWith(p)) return orig.substring(p.length).trim().trimStart(':', ',', '-').trim()
        }
        return null
    }

    /** Yerel komutsa cevabı döner, değilse null. */
    fun tryHandle(raw: String, store: Store): String? {
        val orig = raw.trim().trimEnd('.', '!', '?')
        val q = orig.lowercase(tr)

        if (q == "saat" || q.contains("saat kaç")) {
            return "Saat şu an " + SimpleDateFormat("HH:mm", tr).format(Date()) + "."
        }
        if (q == "tarih" || q.contains("bugün günlerden") || q.contains("bugünün tarihi") || q.contains("bugün ayın kaçı")) {
            return "Bugün " + SimpleDateFormat("d MMMM yyyy, EEEE", tr).format(Date()) + "."
        }

        rest(orig, q, listOf("not ekle", "not al", "not kaydet", "notu ekle"))?.let { t ->
            if (t.isEmpty()) return "Not içeriğini söylemediniz. Örnek: not ekle yarın süt al."
            val l = store.notes()
            l.add(Note(store.nextId(), t.take(40), t, System.currentTimeMillis()))
            store.saveNotes(l)
            return "Notu kaydettim: $t"
        }

        rest(orig, q, listOf("görev ekle", "görev oluştur", "yapılacak ekle"))?.let { t ->
            if (t.isEmpty()) return "Görev metnini söylemediniz. Örnek: görev ekle faturayı öde."
            val l = store.tasks()
            l.add(Task(store.nextId(), t, false))
            store.saveTasks(l)
            return "Görevi ekledim: $t"
        }

        if (q == "notlarım" || q.contains("notlarımı oku") || q.contains("notlarım neler")) {
            val n = store.notes().sortedByDescending { it.updated }
            if (n.isEmpty()) return "Kayıtlı notunuz yok."
            return "${n.size} notunuz var: " + n.take(5).joinToString("; ") { it.title }
        }

        if (q == "görevlerim" || q.contains("görevlerimi oku") || q.contains("görevlerim neler")) {
            val t = store.tasks().filter { !it.done }
            if (t.isEmpty()) return "Bekleyen göreviniz yok."
            return "${t.size} bekleyen göreviniz var: " + t.take(5).joinToString("; ") { it.text }
        }

        rest(orig, q, listOf("hesapla"))?.let { e ->
            val expr = e.lowercase(tr)
                .replace("artı", "+").replace("eksi", "-").replace("çarpı", "*")
                .replace("bölü", "/").replace(" x ", "*")
            return try {
                "Sonuç " + Calc.format(Calc.eval(expr))
            } catch (ex: ArithmeticException) {
                "Sıfıra bölme yapılamaz."
            } catch (ex: Exception) {
                "Bu işlemi anlayamadım. Örnek: hesapla 12 çarpı 4."
            }
        }

        return null
    }
}

class Assistant(private val store: Store, private val voice: Voice) {
    private val main = Handler(Looper.getMainLooper())

    /** Parametre: yeni asistan cevabı (yoksa null). Her zaman ana iş parçacığında çağrılır. */
    val observers = mutableListOf<(String?) -> Unit>()

    var busy = false
        private set
    private var ttsWarned = false

    init {
        voice.onSpeakingChanged = { changed() }
    }

    fun changed(newReply: String? = null) {
        for (o in observers) o(newReply)
    }

    fun ask(text: String) {
        val q = text.trim()
        if (q.isEmpty() || busy) return
        store.addMsg(Msg("user", q, System.currentTimeMillis()))

        val local = Commands.tryHandle(q, store)
        if (local != null) {
            reply(local, false)
            return
        }
        if (!store.aiConfigured()) {
            reply(
                "Gerçek yapay zekâ sohbeti için güvenli bir sunucu adresi gerekiyor ve henüz tanımlı değil. " +
                    "Ayarlar bölümüne https:// ile başlayan sunucu adresinizi girin. " +
                    "Not, görev, saat ve hesap komutları sunucu olmadan çalışır.",
                true
            )
            return
        }

        busy = true
        changed()
        val history = store.chat().takeLast(20)
        val url = store.apiUrl
        val token = store.apiToken
        Thread {
            val result = runCatching { AiClient.chat(url, token, history) }
            main.post {
                busy = false
                result.fold(
                    onSuccess = { reply(it, false) },
                    onFailure = { reply(AiClient.explain(it), true) }
                )
            }
        }.start()
    }

    private fun reply(text: String, error: Boolean) {
        store.addMsg(Msg(if (error) "error" else "assistant", text, System.currentTimeMillis()))
        if (store.speak) {
            val problem = voice.speak(text)
            if (problem != null && !ttsWarned) {
                ttsWarned = true
                store.addMsg(Msg("error", problem, System.currentTimeMillis()))
            }
        }
        changed(text)
    }
}
