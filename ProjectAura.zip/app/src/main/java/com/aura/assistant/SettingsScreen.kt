package com.aura.assistant

import android.app.AlertDialog
import android.text.InputType
import android.view.View
import android.widget.ScrollView
import android.widget.Switch

class SettingsScreen(private val app: MainActivity) : Screen() {
    private val status = tv(app, "", 13f, C.cyan)
    private val url = field(app, "https://sunucunuz.example.com/aura").apply {
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
    }
    private val token = field(app, "Sunucu erişim jetonu (isteğe bağlı)").apply {
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    override val view: View by lazy { build() }

    private fun panel(title: String): android.widget.LinearLayout {
        val p = vbox(app)
        p.background = neon(app, C.panel, C.purple, 14)
        p.setPadding(app.dp(14), app.dp(12), app.dp(14), app.dp(12))
        p.add(tv(app, title, 14f, C.cyan, true), b = 8)
        return p
    }

    private fun build(): View {
        val root = vbox(app)
        root.setPadding(app.dp(12), app.dp(8), app.dp(12), app.dp(12))

        val head = tv(app, "AYARLAR", 16f, C.cyan, true)
        head.typeface = MONO
        root.add(head, b = 8)

        // Ses
        val voice = panel("SES")
        val sw = Switch(app)
        sw.text = "Sesli cevap"
        sw.setTextColor(C.text)
        sw.isChecked = app.store.speak
        sw.setOnCheckedChangeListener { _, c ->
            app.store.speak = c
            if (!c) app.voice.stopSpeaking()
        }
        voice.add(sw)
        voice.add(btn(app, "Sesi dene", C.purple) {
            val problem = app.voice.speak("Merhaba, ben Aura. Sesim çalışıyor.")
            status.text = problem ?: "Ses çalıyor…"
        }, t = 8)
        root.add(voice, b = 10)

        // AI bağlantısı
        val ai = panel("YAPAY ZEKÂ SUNUCUSU")
        ai.add(
            tv(
                app,
                "Gerçek AI sohbeti için kendi güvenli sunucunuzun (proxy) https adresi gerekir. " +
                    "API anahtarı yalnızca sunucuda durur; bu uygulamaya ASLA yazmayın. " +
                    "Aşağıdaki jeton sadece sunucunuza erişim içindir.",
                12f, C.dim
            ),
            b = 8
        )
        url.setText(app.store.apiUrl)
        token.setText(app.store.apiToken)
        ai.add(url)
        ai.add(token, t = 8)
        val row = hbox(app)
        row.add(btn(app, "Kaydet", C.cyan) { save() }, w = 0, weight = 1f, r = 4)
        row.add(btn(app, "Bağlantıyı test et", C.purple) { test() }, w = 0, weight = 1f, l = 4)
        ai.add(row, t = 8)
        root.add(ai, b = 10)

        // Veri
        val data = panel("VERİ")
        data.add(btn(app, "Sohbet geçmişini temizle", C.danger) {
            AlertDialog.Builder(app, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Sohbet geçmişi silinsin mi?")
                .setPositiveButton("Sil") { _, _ ->
                    app.store.clearChat()
                    status.text = "Sohbet geçmişi silindi."
                }
                .setNegativeButton("İptal", null)
                .show()
        })
        root.add(data, b = 10)

        root.add(status, b = 8)
        root.add(tv(app, "PROJECT AURA 0.1.0 · Notlar, görevler ve sohbet geçmişi yalnızca bu telefonda saklanır.", 11f, C.dim))

        val sv = ScrollView(app)
        sv.addView(root)
        return sv
    }

    private fun save(): Boolean {
        val u = url.text.toString().trim()
        if (u.isNotEmpty() && !u.startsWith("https://", ignoreCase = true)) {
            status.setTextColor(C.danger)
            status.text = "Adres https:// ile başlamalı. Güvenlik için http kabul edilmez."
            return false
        }
        app.store.apiUrl = u
        app.store.apiToken = token.text.toString()
        status.setTextColor(C.cyan)
        status.text = if (u.isEmpty()) "Kaydedildi. Sunucu adresi boş: AI sohbeti kapalı." else "Kaydedildi."
        return true
    }

    private fun test() {
        if (!save()) return
        if (!app.store.aiConfigured()) {
            status.setTextColor(C.danger)
            status.text = "Önce bir sunucu adresi girin."
            return
        }
        status.setTextColor(C.cyan)
        status.text = "Bağlantı test ediliyor…"
        val u = app.store.apiUrl
        val t = app.store.apiToken
        val probe = listOf(Msg("user", "Merhaba, bağlantı testi. Tek kısa cümleyle yanıt ver.", System.currentTimeMillis()))
        Thread {
            val r = runCatching { AiClient.chat(u, t, probe) }
            app.runOnUiThread {
                r.fold(
                    onSuccess = {
                        status.setTextColor(C.cyan)
                        status.text = "Bağlantı başarılı. Sunucu yanıtı: " + it.take(120)
                    },
                    onFailure = {
                        status.setTextColor(C.danger)
                        status.text = AiClient.explain(it)
                    }
                )
            }
        }.start()
    }
}
