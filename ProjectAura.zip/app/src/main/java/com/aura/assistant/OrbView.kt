package com.aura.assistant

import android.animation.ArgbEvaluator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** Animasyonlu enerji küresi + ses dalgası çubukları. */
class OrbView(ctx: Context) : View(ctx) {
    enum class Mode { IDLE, LISTENING, THINKING, SPEAKING }

    var mode: Mode = Mode.IDLE
    var level: Float = 0f

    private var smooth = 0f
    private val t0 = System.nanoTime()
    private val ev = ArgbEvaluator()
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val core = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val box = RectF()

    private fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

    override fun onDraw(canvas: Canvas) {
        val t = (System.nanoTime() - t0) / 1_000_000_000f
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h * 0.40f
        val r = min(w / 2f, h * 0.4f) / 2.2f

        val target = when (mode) {
            Mode.LISTENING -> 0.15f + level * 0.85f
            Mode.SPEAKING -> 0.45f + 0.35f * sin(t * 9f) * sin(t * 4.3f)
            Mode.THINKING -> 0.25f + 0.1f * sin(t * 5f)
            Mode.IDLE -> 0.06f
        }
        smooth += (target - smooth) * 0.12f
        val speed = when (mode) {
            Mode.THINKING -> 3.2f
            Mode.LISTENING -> 1.6f
            Mode.SPEAKING -> 1.8f
            Mode.IDLE -> 0.6f
        }
        val rr = r * (1f + 0.04f * sin(t * 2f) + smooth * 0.22f)

        // dış parıltı
        glow.shader = RadialGradient(
            cx, cy, rr * 2.4f,
            intArrayOf(withAlpha(C.purple, 140), withAlpha(C.cyan, 50), 0),
            floatArrayOf(0.25f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, rr * 2.4f, glow)

        // çekirdek
        core.shader = RadialGradient(
            cx - rr * 0.3f, cy - rr * 0.3f, rr * 1.3f,
            intArrayOf(0xFFFFFFFF.toInt(), C.cyan, C.purple, 0xFF1A0638.toInt()),
            floatArrayOf(0f, 0.3f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, rr, core)

        // dönen halkalar
        for (i in 0..2) {
            val radius = rr * (1.35f + i * 0.28f)
            ring.strokeWidth = r * (0.05f + 0.02f * i)
            ring.color = withAlpha(if (i % 2 == 0) C.cyan else C.purple, 220 - i * 50)
            box.set(cx - radius, cy - radius, cx + radius, cy + radius)
            val dir = if (i % 2 == 0) 1f else -1f
            val angle = t * speed * 40f * dir + i * 70f
            val sweep = 70f + smooth * 60f
            canvas.drawArc(box, angle, sweep, false, ring)
            canvas.drawArc(box, angle + 180f, sweep, false, ring)
        }

        // ses dalgası çubukları
        val n = 31
        val span = w * 0.8f
        val x0 = (w - span) / 2f
        val gap = span / (n - 1)
        val baseY = h * 0.86f
        val maxH = h * 0.11f
        bar.strokeWidth = gap * 0.45f
        for (i in 0 until n) {
            val f = i / (n - 1f)
            val env = sin(PI.toFloat() * f)
            val amp = 0.06f + smooth * (0.35f + 0.65f * abs(sin(t * 5f + i * 0.6f)))
            val hgt = maxH * min(amp, 1f) * (0.25f + 0.75f * env)
            bar.color = ev.evaluate(f, C.purple, C.cyan) as Int
            val x = x0 + gap * i
            canvas.drawLine(x, baseY - hgt, x, baseY + hgt, bar)
        }

        postInvalidateOnAnimation()
    }
}
