package com.aura.assistant

import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor

/** Güvenli, harici bağımlılıksız ifade hesaplayıcı: + - * / ( ) ve ondalık sayılar. */
object Calc {
    fun eval(input: String): Double {
        val clean = input
            .replace('÷', '/').replace('×', '*').replace('−', '-')
            .replace(',', '.').replace(" ", "")
        val p = Parser(clean)
        val v = p.expr()
        if (p.i != p.s.length) throw IllegalArgumentException("ifade")
        return v
    }

    fun format(d: Double): String {
        if (d == floor(d) && abs(d) < 1e15) return d.toLong().toString()
        return String.format(Locale.US, "%.8f", d).trimEnd('0').trimEnd('.').replace('.', ',')
    }

    private class Parser(val s: String) {
        var i = 0

        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        fun term(): Double {
            var v = factor()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]
                val r = factor()
                if (op == '*') {
                    v *= r
                } else {
                    if (r == 0.0) throw ArithmeticException("sifira bolme")
                    v /= r
                }
            }
            return v
        }

        fun factor(): Double {
            if (i >= s.length) throw IllegalArgumentException("ifade")
            if (s[i] == '-') {
                i++
                return -factor()
            }
            if (s[i] == '+') {
                i++
                return factor()
            }
            if (s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException("parantez")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("sayi")
            return s.substring(st, i).toDouble()
        }
    }
}
