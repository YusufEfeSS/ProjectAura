package com.aura.assistant

import android.content.res.ColorStateList
import android.graphics.Paint
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.CheckBox
import android.widget.ScrollView

class TasksScreen(private val app: MainActivity) : Screen() {
    private val list = vbox(app)
    private val input = field(app, "Yeni görev…").apply {
        imeOptions = EditorInfo.IME_ACTION_DONE
        setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) {
                add()
                true
            } else {
                false
            }
        }
    }

    override val view: View by lazy { build() }

    private fun build(): View {
        val root = vbox(app)
        root.setPadding(app.dp(12), app.dp(8), app.dp(12), app.dp(8))

        val head = hbox(app)
        val title = tv(app, "GÖREVLER", 16f, C.cyan, true)
        title.typeface = MONO
        head.add(title, w = 0, weight = 1f)
        head.add(btn(app, "Tamamlananları sil", C.dim) { clearDone() })
        root.add(head, b = 8)

        val row = hbox(app)
        row.add(input, w = 0, weight = 1f)
        row.add(btn(app, "Ekle", C.cyan) { add() }, l = 6)
        root.add(row, b = 8)

        val sv = ScrollView(app)
        sv.addView(list)
        root.add(sv, h = 0, weight = 1f)
        return root
    }

    override fun onShow() {
        render()
    }

    private fun add() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        val all = app.store.tasks()
        all.add(Task(app.store.nextId(), t, false))
        app.store.saveTasks(all)
        input.setText("")
        render()
    }

    private fun clearDone() {
        val all = app.store.tasks()
        all.removeAll { it.done }
        app.store.saveTasks(all)
        render()
    }

    private fun render() {
        list.removeAllViews()
        val tasks = app.store.tasks().sortedBy { it.done }
        if (tasks.isEmpty()) {
            list.add(tv(app, "Görev yok. Yazarak veya “görev ekle …” diyerek ekleyin.", 14f, C.dim), t = 16)
            return
        }
        for (t in tasks) {
            val row = hbox(app)
            row.background = neon(app, C.panel, if (t.done) C.dim else C.purple, 12)
            row.setPadding(app.dp(8), app.dp(4), app.dp(8), app.dp(4))

            val cb = CheckBox(app)
            cb.isChecked = t.done
            cb.buttonTintList = ColorStateList.valueOf(C.cyan)
            cb.setOnCheckedChangeListener { _, checked ->
                val all = app.store.tasks()
                all.find { it.id == t.id }?.done = checked
                app.store.saveTasks(all)
                list.post { render() }
            }
            row.add(cb)

            val label = tv(app, t.text, 15f, if (t.done) C.dim else C.text)
            if (t.done) label.paintFlags = label.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            row.add(label, w = 0, weight = 1f)

            row.add(btn(app, "✕", C.danger) {
                val all = app.store.tasks()
                all.removeAll { it.id == t.id }
                app.store.saveTasks(all)
                render()
            })
            list.add(row, b = 8)
        }
    }
}
