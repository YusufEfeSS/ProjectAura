package com.aura.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    lateinit var store: Store
    lateinit var voice: Voice
    lateinit var assistant: Assistant

    private lateinit var content: FrameLayout
    private val screens = ArrayList<Screen>()
    private val tabs = ArrayList<TextView>()
    private var current = -1
    private var pendingMic: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C.bg
        window.navigationBarColor = C.bg

        store = Store(this)
        voice = Voice(this)
        assistant = Assistant(store, voice)

        screens.add(HomeScreen(this))
        screens.add(ChatScreen(this))
        screens.add(NotesScreen(this))
        screens.add(TasksScreen(this))
        screens.add(ToolsScreen(this))
        screens.add(SettingsScreen(this))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.bg)
        }
        root.setOnApplyWindowInsetsListener { v, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(i.left, i.top, i.right, i.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(
                    ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                    ins.systemWindowInsetRight, ins.systemWindowInsetBottom
                )
            }
            ins
        }

        content = FrameLayout(this)
        root.add(content, h = 0, weight = 1f)

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(C.panel2)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val names = listOf("Aura", "Sohbet", "Notlar", "Görevler", "Araçlar", "Ayarlar")
        for ((i, n) in names.withIndex()) {
            val t = tv(this, n, 11f, C.dim, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(10), 0, dp(10))
            t.setOnClickListener { select(i) }
            tabs.add(t)
            bar.add(t, w = 0, weight = 1f, l = 2, r = 2)
        }
        root.add(bar)

        setContentView(root)
        select(0)
    }

    fun select(i: Int) {
        if (current == i) return
        if (current >= 0) screens[current].onHide()
        hideKeyboard()
        content.removeAllViews()
        content.addView(screens[i].view, FrameLayout.LayoutParams(MATCH, MATCH))
        current = i
        screens[i].onShow()
        for ((idx, t) in tabs.withIndex()) {
            val on = idx == i
            t.setTextColor(if (on) C.cyan else C.dim)
            t.background = if (on) neon(this, C.selected, C.cyan, 10) else null
        }
    }

    private fun hideKeyboard() {
        val f = currentFocus ?: return
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(f.windowToken, 0)
    }

    /** Mikrofon izni varsa hemen, yoksa izin istedikten sonra [then] çalışır. */
    fun ensureMic(then: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            then()
            return
        }
        pendingMic = then
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 7) return
        val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        val cb = pendingMic
        pendingMic = null
        if (ok) cb?.invoke() else showMicDenied()
    }

    private fun showMicDenied() {
        val permanent = !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)
        val b = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Mikrofon izni gerekli")
            .setMessage(
                if (permanent) {
                    "Sesli komutlar için mikrofon izni kapalı. Uygulama ayarlarından Mikrofon iznini açabilirsiniz. " +
                        "İzin vermeden de yazarak sohbet edebilirsiniz."
                } else {
                    "Sesli komutlar için mikrofon izni gerekiyor. Tekrar denediğinizde izin isteği yeniden görünecek. " +
                        "İzin vermeden de yazarak sohbet edebilirsiniz."
                }
            )
            .setNegativeButton("Kapat", null)
        if (permanent) {
            b.setPositiveButton("Ayarları aç") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
                )
            }
        }
        b.show()
    }

    override fun onPause() {
        super.onPause()
        voice.cancelListening()
    }

    override fun onDestroy() {
        voice.release()
        super.onDestroy()
    }
}
