package com.aura.assistant

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.SSLException

/**
 * Kendi güvenli sunucunuza (proxy) bağlanır. Uygulamada HİÇBİR yapay zekâ API anahtarı bulunmaz.
 *
 * İstek : POST {url}  {"messages":[{"role":"user|assistant","content":"..."}], "lang":"tr"}
 * Cevap : {"reply":"..."}
 */
object AiClient {
    class HttpError(val code: Int) : Exception("HTTP $code")

    fun chat(url: String, token: String, history: List<Msg>): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("Accept", "application/json")
            if (token.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer " + token.trim())

            val arr = JSONArray()
            for (m in history) {
                if (m.role == "user" || m.role == "assistant") {
                    arr.put(JSONObject().put("role", m.role).put("content", m.text))
                }
            }
            val body = JSONObject().put("messages", arr).put("lang", "tr").toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            if (code !in 200..299) throw HttpError(code)
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val reply = JSONObject(text).optString("reply", "")
            if (reply.isBlank()) throw IllegalStateException("bos-yanit")
            return reply.trim()
        } finally {
            conn.disconnect()
        }
    }

    fun explain(e: Throwable): String = when (e) {
        is HttpError -> when (e.code) {
            401, 403 -> "Sunucu erişimi reddetti. Ayarlar'daki erişim jetonunu kontrol edin."
            404 -> "Sunucu adresi bulunamadı (404). Ayarlar'daki adresi kontrol edin."
            429 -> "Çok fazla istek gönderildi. Biraz bekleyip tekrar deneyin."
            in 500..599 -> "Sunucu veya yapay zekâ servisi şu an hata veriyor (${e.code}). Sonra tekrar deneyin."
            else -> "Sunucu beklenmeyen bir yanıt verdi (HTTP ${e.code})."
        }
        is UnknownHostException -> "Sunucuya ulaşılamıyor. İnternet bağlantınızı ve sunucu adresini kontrol edin."
        is ConnectException -> "Sunucuya bağlanılamadı. Adres doğru mu ve sunucu çalışıyor mu?"
        is SocketTimeoutException -> "Sunucu zamanında yanıt vermedi. Bağlantınızı kontrol edip tekrar deneyin."
        is SSLException -> "Güvenli bağlantı (SSL) kurulamadı. Adresin geçerli bir https sertifikası olmalı."
        is MalformedURLException -> "Sunucu adresi geçersiz. Ayarlar'da https:// ile başlayan bir adres girin."
        is JSONException -> "Sunucu yanıtı beklenen biçimde değil. Yanıt {\"reply\":\"...\"} olmalı."
        is IllegalStateException -> "Sunucu boş yanıt döndürdü."
        else -> "Bağlantı hatası: ${e.javaClass.simpleName}"
    }
}
