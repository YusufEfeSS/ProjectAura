package com.aura.assistant

import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.ScrollView
import android.widget.TextView

class HomeScreen(private val app: MainActivity) : Screen() {
    private val orb = OrbView(app)

    private val status = tv(app, "Dokun ve Türkçe konuş", 14f, C.cyan, true).apply {
        gravity = Gravity.CENTER
        typeface = MONO
    }

    private val reply = tv(app, "Merhaba, ben Aura. Mikrofona dokunup konuşabilirsiniz.", 15f, C.text).apply {
        gravity = Gravity.CENTER
    }

    private val mic = TextView(app).apply {
        text = "🎤"
        textSize = 30f
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(C.panel)
            setStroke(app.dp(2), C.cyan)
        }
        setOnClickListener { toggle() }
    }

    init {
        app.assistant.observers.add { r ->
            if (r != null) {
                reply.text = r
                reply.setTextColor(C.text)
            }
            updateMode()
        }
    }

    override val view: View by lazy { build() }

    private fun build(): View {
        val root = vbox(app)
        root.setPadding(app.dp(16), app.dp(8), app.dp(16), app.dp(8))

        val title = tv(app, "P R O J E C T   A U R A", 16f, C.cyan, true)
        title.gravity = Gravity.CENTER
        title.typeface = MONO
        title.letterSpacing = 0.15f
        root.add(title, t = 4)

        root.add(orb, h = 0, weight = 1f)
        root.add(status, t = 4)

        val sv = ScrollView(app)
        sv.addView(reply)
        root.add(sv, h = app.dp(96), t = 8)

        root.add(mic, w = app.dp(76), h = app.dp(76), t = 8, b = 8, g = Gravity.CENTER_HORIZONTAL)
        return root
    }

    override fun onShow() {
        updateMode()
    }

    private fun toggle() {
        val v = app.voice
        if (v.speaking) {
            v.stopSpeaking()
            return
        }
        if (v.listening) {
            v.stopListening()
            return
        }
        if (app.assistant.busy) return
        app.ensureMic { startListen() }
    }

    private fun startListen() {
        reply.setTextColor(C.text)
        reply.text = ""
        app.voice.startListening(
            cbPartial = { reply.text = it },
            cbFinal = {
                reply.text = "“$it”"
                app.assistant.ask(it)
            },
            cbError = {
                reply.text = it
                reply.setTextColor(C.danger)
            },
            cbLevel = { orb.level = it },
            cbEnd = {
                orb.level = 0f
                updateMode()
            }
        )
        updateMode()
    }

    private fun updateMode() {
        val v = app.voice
        val a = app.assistant
        val m: OrbView.Mode
        val s: String
        when {
            v.listening -> {
                m = OrbView.Mode.LISTENING
                s = "Dinliyorum…"
            }
            a.busy -> {
                m = OrbView.Mode.THINKING
                s = "Düşünüyorum…"
            }
            v.speaking -> {
                m = OrbView.Mode.SPEAKING
                s = "Konuşuyorum… (durdurmak için dokun)"
            }
            else -> {
                m = OrbView.Mode.IDLE
                s = "Dokun ve Türkçe konuş"
            }
        }
        orb.mode = m
        status.text = s
        (mic.background as GradientDrawable).setStroke(app.dp(2), if (v.listening) C.danger else C.cyan)
    }
}
