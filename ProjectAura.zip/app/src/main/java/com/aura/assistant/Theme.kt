package com.aura.assistant

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val bg = 0xFF07050F.toInt()
    val panel = 0xFF140F26.toInt()
    val panel2 = 0xFF0D0A1C.toInt()
    val selected = 0xFF2A1450.toInt()
    val purple = 0xFFB026FF.toInt()
    val cyan = 0xFF00F0FF.toInt()
    val text = 0xFFEAF6FF.toInt()
    val dim = 0xFF8C86A8.toInt()
    val danger = 0xFFFF4D6D.toInt()
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
val MONO: Typeface = Typeface.MONOSPACE

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun neon(ctx: Context, fill: Int = C.panel, stroke: Int = C.cyan, radius: Int = 14, strokeDp: Int = 1): GradientDrawable =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = ctx.dp(radius).toFloat()
        setStroke(ctx.dp(strokeDp), stroke)
    }

fun tv(ctx: Context, s: CharSequence, size: Float = 15f, color: Int = C.text, bold: Boolean = false): TextView =
    TextView(ctx).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

fun styleBtn(b: Button, accent: Int, selected: Boolean = false) {
    val ctx = b.context
    val shape = neon(ctx, if (selected) C.selected else C.panel, accent, 12, if (selected) 2 else 1)
    val mask = neon(ctx, 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 12)
    b.background = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), shape, mask)
    b.setTextColor(accent)
}

fun btn(ctx: Context, label: String, accent: Int = C.cyan, onClick: () -> Unit): Button =
    Button(ctx).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        stateListAnimator = null
        minHeight = 0
        minimumHeight = 0
        setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(14), ctx.dp(10))
        styleBtn(this, accent)
        setOnClickListener { onClick() }
    }

fun field(ctx: Context, hintText: String, multiline: Boolean = false): EditText =
    EditText(ctx).apply {
        hint = hintText
        setHintTextColor(C.dim)
        setTextColor(C.text)
        textSize = 15f
        background = neon(ctx, C.panel2, C.purple, 12)
        setPadding(ctx.dp(12), ctx.dp(10), ctx.dp(12), ctx.dp(10))
        inputType = if (multiline) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        } else {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        if (multiline) {
            gravity = Gravity.TOP or Gravity.START
            minLines = 4
        }
    }

fun vbox(ctx: Context): LinearLayout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

fun hbox(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

/** Kenar boşlukları dp cinsindendir. */
fun LinearLayout.add(
    v: View,
    w: Int = MATCH,
    h: Int = WRAP,
    weight: Float = 0f,
    l: Int = 0,
    t: Int = 0,
    r: Int = 0,
    b: Int = 0,
    g: Int = -1
) {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
    if (g != -1) p.gravity = g
    addView(v, p)
}

abstract class Screen {
    abstract val view: View
    open fun onShow() {}
    open fun onHide() {}
}
