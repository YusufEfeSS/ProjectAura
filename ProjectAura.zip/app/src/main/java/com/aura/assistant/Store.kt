package com.aura.assistant

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Note(val id: Long, var title: String, var body: String, var updated: Long)
data class Task(val id: Long, var text: String, var done: Boolean)
data class Msg(val role: String, val text: String, val time: Long)

/** Tüm yerel kayıtlar cihazda SharedPreferences içinde JSON olarak tutulur. */
class Store(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("aura_store", Context.MODE_PRIVATE)

    fun nextId(): Long {
        val n = sp.getLong("seq", 1L)
        sp.edit().putLong("seq", n + 1).apply()
        return n
    }

    private fun <T> readArray(key: String, f: (JSONObject) -> T): MutableList<T> {
        val out = ArrayList<T>()
        try {
            val a = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until a.length()) out.add(f(a.getJSONObject(i)))
        } catch (e: Exception) {
            // bozuk kayıt: boş liste ile devam et
        }
        return out
    }

    private fun <T> writeArray(key: String, list: List<T>, f: (T) -> JSONObject) {
        val a = JSONArray()
        for (x in list) a.put(f(x))
        sp.edit().putString(key, a.toString()).apply()
    }

    // ---- Notlar ----
    fun notes(): MutableList<Note> = readArray("notes") {
        Note(it.getLong("id"), it.optString("title"), it.optString("body"), it.optLong("updated"))
    }

    fun saveNotes(list: List<Note>) = writeArray("notes", list) {
        JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("updated", it.updated)
    }

    // ---- Görevler ----
    fun tasks(): MutableList<Task> = readArray("tasks") {
        Task(it.getLong("id"), it.optString("text"), it.optBoolean("done"))
    }

    fun saveTasks(list: List<Task>) = writeArray("tasks", list) {
        JSONObject().put("id", it.id).put("text", it.text).put("done", it.done)
    }

    // ---- Sohbet geçmişi ----
    fun chat(): MutableList<Msg> = readArray("chat") {
        Msg(it.optString("role"), it.optString("text"), it.optLong("time"))
    }

    fun addMsg(m: Msg) {
        val l = chat()
        l.add(m)
        val trimmed = if (l.size > 300) l.subList(l.size - 300, l.size) else l
        writeArray("chat", trimmed) {
            JSONObject().put("role", it.role).put("text", it.text).put("time", it.time)
        }
    }

    fun clearChat() {
        sp.edit().remove("chat").apply()
    }

    // ---- Ayarlar ----
    var apiUrl: String
        get() = sp.getString("api_url", "") ?: ""
        set(v) {
            sp.edit().putString("api_url", v.trim()).apply()
        }

    /** Kendi sunucunuzun erişim jetonu. Yapay zekâ servisinin API anahtarı DEĞİLDİR. */
    var apiToken: String
        get() = sp.getString("api_token", "") ?: ""
        set(v) {
            sp.edit().putString("api_token", v.trim()).apply()
        }

    var speak: Boolean
        get() = sp.getBoolean("speak", true)
        set(v) {
            sp.edit().putBoolean("speak", v).apply()
        }

    fun aiConfigured(): Boolean = apiUrl.startsWith("https://", ignoreCase = true) && apiUrl.length > 12
}
