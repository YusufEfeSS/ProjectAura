package com.aura.assistant

import android.app.AlertDialog
import android.view.View
import android.widget.ScrollView
import java.text.SimpleDateFormat
import java.util.Locale

class NotesScreen(private val app: MainActivity) : Screen() {
    private val list = vbox(app)
    private val fmt = SimpleDateFormat("d MMM HH:mm", Locale("tr", "TR"))

    override val view: View by lazy { build() }

    private fun build(): View {
        val root = vbox(app)
        root.setPadding(app.dp(12), app.dp(8), app.dp(12), app.dp(8))

        val head = hbox(app)
        val title = tv(app, "NOTLAR", 16f, C.cyan, true)
        title.typeface = MONO
        head.add(title, w = 0, weight = 1f)
        head.add(btn(app, "+ Yeni not", C.cyan) { edit(null) })
        root.add(head, b = 8)

        val sv = ScrollView(app)
        sv.addView(list)
        root.add(sv, h = 0, weight = 1f)
        return root
    }

    override fun onShow() {
        render()
    }

    private fun render() {
        list.removeAllViews()
        val notes = app.store.notes().sortedByDescending { it.updated }
        if (notes.isEmpty()) {
            list.add(tv(app, "Henüz not yok. “+ Yeni not” ile ekleyin veya “not ekle …” deyin.", 14f, C.dim), t = 16)
            return
        }
        for (n in notes) {
            val card = vbox(app)
            card.background = neon(app, C.panel, C.purple, 14)
            card.setPadding(app.dp(14), app.dp(10), app.dp(14), app.dp(10))
            card.add(tv(app, n.title.ifBlank { "(başlıksız)" }, 16f, C.cyan, true))
            if (n.body.isNotBlank()) {
                val b = tv(app, n.body, 14f, C.text)
                b.maxLines = 3
                card.add(b, t = 4)
            }
            card.add(tv(app, fmt.format(n.updated), 11f, C.dim), t = 6)
            card.setOnClickListener { edit(n) }
            list.add(card, b = 8)
        }
    }

    private fun edit(n: Note?) {
        val box = vbox(app)
        box.setPadding(app.dp(16), app.dp(8), app.dp(16), 0)
        val title = field(app, "Başlık")
        title.setText(n?.title ?: "")
        val body = field(app, "Not", true)
        body.setText(n?.body ?: "")
        box.add(title)
        box.add(body, t = 8)

        val b = AlertDialog.Builder(app, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(if (n == null) "Yeni not" else "Notu düzenle")
            .setView(box)
            .setPositiveButton("Kaydet") { _, _ -> save(n, title.text.toString(), body.text.toString()) }
            .setNegativeButton("İptal", null)
        if (n != null) b.setNeutralButton("Sil") { _, _ -> confirmDelete(n) }
        b.show()
    }

    private fun save(n: Note?, titleIn: String, bodyIn: String) {
        val body = bodyIn.trim()
        var title = titleIn.trim()
        if (title.isEmpty() && body.isEmpty()) return
        if (title.isEmpty()) title = body.lineSequence().first().take(40)
        val all = app.store.notes()
        if (n == null) {
            all.add(Note(app.store.nextId(), title, body, System.currentTimeMillis()))
        } else {
            val target = all.find { it.id == n.id } ?: return
            target.title = title
            target.body = body
            target.updated = System.currentTimeMillis()
        }
        app.store.saveNotes(all)
        render()
    }

    private fun confirmDelete(n: Note) {
        AlertDialog.Builder(app, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Not silinsin mi?")
            .setMessage(n.title)
            .setPositiveButton("Sil") { _, _ ->
                val all = app.store.notes()
                all.removeAll { it.id == n.id }
                app.store.saveNotes(all)
                render()
            }
            .setNegativeButton("İptal", null)
            .show()
    }
}
