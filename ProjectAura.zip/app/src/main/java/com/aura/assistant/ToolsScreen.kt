package com.aura.assistant

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ScrollView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Hesap makinesi, saat ve kronometre. */
class ToolsScreen(private val app: MainActivity) : Screen() {
    private val main = Handler(Looper.getMainLooper())
    private val host = FrameLayout(app)
    private val subViews = ArrayList<View>()
    private val subButtons = ArrayList<Button>()
    private var visible = false
    private var sub = 0

    // saat
    private val clockTime = tv(app, "", 44f, C.cyan, true).apply {
        gravity = Gravity.CENTER
        typeface = MONO
    }
    private val clockDate = tv(app, "", 16f, C.text).apply { gravity = Gravity.CENTER }
    private val clockTick = object : Runnable {
        override fun run() {
            updateClock()
            if (visible && sub == 1) main.postDelayed(this, 500)
        }
    }

    // kronometre
    private val swTime = tv(app, "00:00.00", 48f, C.cyan, true).apply {
        gravity = Gravity.CENTER
        typeface = MONO
    }
    private val swLaps = vbox(app)
    private lateinit var swStart: Button
    private var swRunning = false
    private var swBase = 0L
    private var swAccum = 0L
    private var swLapCount = 0
    private val swTick = object : Runnable {
        override fun run() {
            swTime.text = fmt(swElapsed())
            if (visible && sub == 2 && swRunning) main.postDelayed(this, 40)
        }
    }

    override val view: View by lazy { build() }

    private fun build(): View {
        val root = vbox(app)
        root.setPadding(app.dp(12), app.dp(8), app.dp(12), app.dp(8))

        val title = tv(app, "ARAÇLAR", 16f, C.cyan, true)
        title.typeface = MONO
        root.add(title, b = 8)

        val names = listOf("Hesap", "Saat", "Kronometre")
        val tabRow = hbox(app)
        for ((i, n) in names.withIndex()) {
            val b = btn(app, n, C.cyan) { selectSub(i) }
            subButtons.add(b)
            tabRow.add(b, w = 0, weight = 1f, l = 2, r = 2)
        }
        root.add(tabRow, b = 8)

        subViews.add(calcView())
        subViews.add(clockView())
        subViews.add(stopwatchView())
        root.add(host, h = 0, weight = 1f)
        return root
    }

    override fun onShow() {
        visible = true
        selectSub(sub, force = true)
    }

    override fun onHide() {
        visible = false
        main.removeCallbacksAndMessages(null)
    }

    private fun selectSub(i: Int, force: Boolean = false) {
        if (!force && i == sub) return
        sub = i
        main.removeCallbacksAndMessages(null)
        host.removeAllViews()
        host.addView(subViews[i], FrameLayout.LayoutParams(MATCH, MATCH))
        for ((idx, b) in subButtons.withIndex()) styleBtn(b, C.cyan, idx == i)
        if (i == 1) clockTick.run()
        if (i == 2) swTick.run()
    }

    // ---- Hesap makinesi ----
    private fun calcView(): View {
        val box = vbox(app)
        val exprView = tv(app, "", 14f, C.dim).apply { gravity = Gravity.END }
        val display = tv(app, "0", 34f, C.cyan, true).apply {
            gravity = Gravity.END
            typeface = MONO
            maxLines = 1
            background = neon(app, C.panel2, C.purple, 12)
            setPadding(app.dp(12), app.dp(12), app.dp(12), app.dp(12))
        }
        box.add(exprView, t = 4)
        box.add(display, t = 4, b = 8)

        var cur = ""

        fun press(k: String) {
            when (k) {
                "C" -> {
                    cur = ""
                    exprView.text = ""
                }
                "⌫" -> {
                    if (cur.isNotEmpty()) cur = cur.dropLast(1)
                }
                "=" -> {
                    if (cur.isNotEmpty()) {
                        try {
                            val r = Calc.format(Calc.eval(cur))
                            exprView.text = "$cur ="
                            cur = r
                        } catch (e: ArithmeticException) {
                            exprView.text = "Sıfıra bölünemez"
                        } catch (e: Exception) {
                            exprView.text = "Geçersiz ifade"
                        }
                    }
                }
                else -> cur += k
            }
            display.text = if (cur.isEmpty()) "0" else cur
        }

        val rows = listOf(
            listOf("C", "⌫", "(", ")"),
            listOf("7", "8", "9", "÷"),
            listOf("4", "5", "6", "×"),
            listOf("1", "2", "3", "−"),
            listOf("0", ",", "=", "+")
        )
        for (r in rows) {
            val row = hbox(app)
            for (k in r) {
                val accent = when (k) {
                    "=" -> C.cyan
                    "C", "⌫" -> C.danger
                    "÷", "×", "−", "+", "(", ")" -> C.purple
                    else -> C.text
                }
                row.add(btn(app, k, accent) { press(k) }, w = 0, h = app.dp(58), weight = 1f, l = 3, t = 3, r = 3, b = 3)
            }
            box.add(row)
        }
        return box
    }

    // ---- Saat ----
    private fun clockView(): View {
        val box = vbox(app)
        box.gravity = Gravity.CENTER
        box.add(clockTime, t = 40)
        box.add(clockDate, t = 8)
        return box
    }

    private fun updateClock() {
        val tr = Locale("tr", "TR")
        val now = Date()
        clockTime.text = SimpleDateFormat("HH:mm:ss", tr).format(now)
        clockDate.text = SimpleDateFormat("d MMMM yyyy, EEEE", tr).format(now)
    }

    // ---- Kronometre ----
    private fun swElapsed(): Long =
        if (swRunning) swAccum + SystemClock.elapsedRealtime() - swBase else swAccum

    private fun fmt(ms: Long): String {
        val cs = ms / 10 % 100
        val s = ms / 1000 % 60
        val m = ms / 60000 % 60
        val h = ms / 3600000
        return if (h > 0) {
            String.format(Locale.US, "%d:%02d:%02d.%02d", h, m, s, cs)
        } else {
            String.format(Locale.US, "%02d:%02d.%02d", m, s, cs)
        }
    }

    private fun stopwatchView(): View {
        val box = vbox(app)
        box.setPadding(app.dp(8), app.dp(16), app.dp(8), app.dp(8))
        box.add(swTime, t = 8, b = 16)

        swStart = btn(app, "Başlat", C.cyan) { toggleSw() }
        val lap = btn(app, "Tur", C.purple) { if (swRunning) lapSw() }
        val reset = btn(app, "Sıfırla", C.danger) { resetSw() }
        val row = hbox(app)
        row.add(swStart, w = 0, weight = 1f, r = 4)
        row.add(lap, w = 0, weight = 1f, l = 2, r = 2)
        row.add(reset, w = 0, weight = 1f, l = 4)
        box.add(row)

        val sv = ScrollView(app)
        sv.addView(swLaps)
        box.add(sv, h = 0, weight = 1f, t = 12)
        return box
    }

    private fun toggleSw() {
        if (swRunning) {
            swAccum += SystemClock.elapsedRealtime() - swBase
            swRunning = false
            swStart.text = "Devam"
            swTime.text = fmt(swElapsed())
        } else {
            swBase = SystemClock.elapsedRealtime()
            swRunning = true
            swStart.text = "Durdur"
            swTick.run()
        }
    }

    private fun lapSw() {
        swLapCount += 1
        val line = tv(app, "Tur $swLapCount    ${fmt(swElapsed())}", 16f, C.text)
        line.typeface = MONO
        line.setPadding(app.dp(8), app.dp(6), app.dp(8), app.dp(6))
        swLaps.addView(line, 0)
    }

    private fun resetSw() {
        swRunning = false
        swAccum = 0L
        swLapCount = 0
        swStart.text = "Başlat"
        swTime.text = fmt(0L)
        swLaps.removeAllViews()
    }
}
